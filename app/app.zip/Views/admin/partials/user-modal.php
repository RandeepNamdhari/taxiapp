<div class="modal fade bs-users-modal-center" tabindex="-1" aria-labelledby="mySmallModalLabel" aria-modal="true" role="dialog" style="display: none; padding-left: 0px;">
                                                    <div class="modal-dialog modal-dialog-centered ">
                                                        <div class="modal-content border-0">
                                                            <div class="modal-header bg-success p-2 m-0">
                                                                <h5 class="modal-title ">Users List</h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <div class="modal-body">

                                                                <div class="col-sm-12 border-0">
                                                <input class="form-control border-0" type="text" placeholder="Search with user name..."  id="searchUserInList" onkeyup="__searchUser(this)">
                                                <input type="hidden" name="type" id="existingUsersType">
                                                <input type="hidden" name="model_id" id="modelId">
                                            </div>


                                            <div data-simplebar="init" style="max-height: 230px;" class="simplebar-dragging"><div class="simplebar-wrapper" style="margin: 0px;"><div class="simplebar-height-auto-observer-wrapper"><div class="simplebar-height-auto-observer"></div></div><div class="simplebar-mask"><div class="simplebar-offset" style="right: -15px; bottom: 0px;"><div class="simplebar-content-wrapper" style="height: auto; overflow: hidden scroll;"><div class="simplebar-content" id="userlist_content" style="padding: 0px;">

                                   <!--  <a href="" class="text-reset notification-item">
                                        <div class="d-flex" style="align-items: center;">
                                            <div class="flex-shrink-0 me-3">
                                                <div class="avatar-xs">
                                                    <span class="avatar-title bg-success rounded-circle font-size-16">
                                                        <i class="mdi mdi-cart-outline"></i>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="flex-grow-1">
                                                <h6 class="">Your order is placed</h6>
                                                
                                            </div>

                                             <div class="d-flex w-25" style="pointer-events: all;">
                                                <div class="">
                                                   <input class="form-check" type="checkbox" style="width: 50px;">
                                                </div>
                                            </div>
                                        </div>
                                    </a> -->
                        
                                   
                                </div></div></div></div><div class="simplebar-placeholder" style="width: auto; height: 407px;"></div></div><div class="simplebar-track simplebar-horizontal" style="visibility: hidden;"><div class="simplebar-scrollbar" style="transform: translate3d(0px, 0px, 0px); display: none;"></div></div><div class="simplebar-track simplebar-vertical" style="visibility: visible;"><div class="simplebar-scrollbar" style="transform: translate3d(0px, 101px, 0px); display: block; height: 129px;"></div></div></div>



                                                             
                                                            </div>
                                                        </div>
                                                        <!-- /.modal-content -->
                                                    </div>
                                                    <!-- /.modal-dialog -->
                                                </div>