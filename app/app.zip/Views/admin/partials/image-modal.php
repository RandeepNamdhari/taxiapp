<div class="modal fade bs-example-modal-lg" tabindex="-1" aria-labelledby="myExtraLargeModalLabel" style="display: none;" aria-hidden="true">
                                                    <div class="modal-dialog modal-xl">
                                                        <div class="modal-content bg-light border-0">
                                                          <div class="modal-header">
                                                                <h5 class="modal-title" id="myExtraLargeModalLabel">
                                                                    Files</h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div> 
                                                            <div class="modal-body p-0"><div class="row">
                                                          
                            <div class="col-lg-12">

                                <div class="card">
                                    <div class="card-body p-0">
        
                                     
                                        <div id="carouselExampleFade" class="carousel slide carousel-fade" data-bs-ride="carousel">


                                            <div class="carousel-inner" id="imageModalContent">
                                             
                                              
                                            </div>
                                            <a class="carousel-control-prev" href="#carouselExampleFade" role="button" data-bs-slide="prev">
                                              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                              <span class="sr-only">Previous</span>
                                            </a>
                                            <a class="carousel-control-next" href="#carouselExampleFade" role="button" data-bs-slide="next">
                                              <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                              <span class="sr-only">Next</span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                                                            </div>
                                                        </div>
                                                        <!-- /.modal-content -->
                                                    </div>
                                                    <!-- /.modal-dialog -->
                                                </div>